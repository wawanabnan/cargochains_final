<?php
declare(strict_types=1);

namespace Sales;

use Cake\Core\BasePlugin;

class Plugin extends BasePlugin
{
}
