
<?php
declare(strict_types=1);
namespace Sales\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;
class QuotationsTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);
        $this->setTable('sales_quotations');
        $this->setPrimaryKey('id');
        $this->setDisplayField('code');
        $this->addBehavior('Timestamp');
        $this->belongsTo('Partners.Partners', [
            'foreignKey' => 'partner_id',
        ]);
    }
    public function validationDefault(Validator $v): Validator
    {
        return $v
            ->scalar('code')->maxLength('code', 50)->notEmptyString('code')
            ->scalar('status')->maxLength('status', 20)->notEmptyString('status')
            ->date('quotation_date')->allowEmptyDate('quotation_date')
            ->numeric('total')->allowEmptyString('total');
    }
}
