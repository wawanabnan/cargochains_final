
<?php
declare(strict_types=1);
namespace Sales\Controller;
use Cake\I18n\FrozenDate;
class QuotationsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();
        $this->loadModel('Sales.Quotations'); // explicit
        $this->viewBuilder()->setLayout('adminlte');
        $this->paginate = [
            'limit' => 20,
            'order' => ['Quotations.created' => 'DESC'],
            'contain' => ['Partners.Partners'],
        ];
    }
    public function index()
    {
        $q = $this->request->getQuery('q');
        $status = $this->request->getQuery('status');
        $from = $this->request->getQuery('from');
        $to   = $this->request->getQuery('to');

        $query = $this->Quotations->find()->contain(['Partners.Partners']);
        if ($q) {
            $query->where([
                'OR' => [
                    'Quotations.code LIKE' => "%{$q}%",
                    'Quotations.subject LIKE' => "%{$q}%",
                ]
            ]);
        }
        if ($status) {
            $query->where(['Quotations.status' => $status]);
        }
        if ($from) {
            $query->where(['DATE(Quotations.quotation_date) >=' => FrozenDate::parseDate($from, 'yyyy-MM-dd')]);
        }
        if ($to) {
            $query->where(['DATE(Quotations.quotation_date) <=' => FrozenDate::parseDate($to, 'yyyy-MM-dd')]);
        }

        $this->paginate['url'] = ['?' => $this->request->getQueryParams()];
        $quotations = $this->paginate($query);
        $this->set(compact('quotations'));
    }
    public function view($id = null)
    {
        $quotation = $this->Quotations->get($id, contain: ['Partners.Partners']);
        $this->set(compact('quotation'));
    }
    public function add()
    {
        $quotation = $this->Quotations->newEmptyEntity();
        if ($this->request->is('post')) {
            $quotation = $this->Quotations->patchEntity($quotation, $this->request->getData());
            if ($this->Quotations->save($quotation)) {
                $this->Flash->success(__('Quotation has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Failed to save quotation.'));
        }
        $partners = $this->Quotations->Partners->find('list')->all();
        $this->set(compact('quotation', 'partners'));
    }
    public function edit($id = null)
    {
        $quotation = $this->Quotations->get($id);
        if ($this->request->is(['patch','post','put'])) {
            $quotation = $this->Quotations->patchEntity($quotation, $this->request->getData());
            if ($this->Quotations->save($quotation)) {
                $this->Flash->success(__('Quotation has been updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Failed to update quotation.'));
        }
        $partners = $this->Quotations->Partners->find('list')->all();
        $this->set(compact('quotation','partners'));
    }
    public function delete($id = null)
    {
        $this->request->allowMethod(['post','delete']);
        $quotation = $this->Quotations->get($id);
        if ($this->Quotations->delete($quotation)) {
            $this->Flash->success(__('Quotation deleted.'));
        } else {
            $this->Flash->error(__('Quotation could not be deleted.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
