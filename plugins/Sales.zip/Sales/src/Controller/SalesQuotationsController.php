<?php
declare(strict_types=1);

namespace Sales\Controller;

use App\Controller\AppController;
use Cake\I18n\FrozenDate;

class SalesQuotationsController extends AppController
{

	 public function initialize(): void
    {
        parent::initialize();
        $this->loadModel('Sales.Quotations');
        $this->loadModel('Sales.Customers'); // asumsi ada tabel Customers
        $this->viewBuilder()->setLayout('adminlte'); // layout kamu
        $this->paginate = [
            'limit' => 20,
            'order' => ['Quotations.created' => 'DESC'],
            'contain' => ['Customers'], // jika ada relasi
        ];
    }
    public function index()
    {
			$q   = trim((string)$this->request->getQuery('q'));
        $st  = $this->request->getQuery('status');
        $cid = $this->request->getQuery('customer_id');
        $from = $this->request->getQuery('from'); // yyyy-mm-dd
        $to   = $this->request->getQuery('to');   // yyyy-mm-dd

        $query = $this->Quotations->find();

        if ($q !== '') {
            $query->where([
                'OR' => [
                    'Quotations.code LIKE' => "%{$q}%",
                    'Quotations.subject LIKE' => "%{$q}%",
                ],
            ]);
        }
        if ($st !== null && $st !== '') {
            $query->where(['Quotations.status' => $st]);
        }
        if ($cid !== null && $cid !== '') {
            $query->where(['Quotations.customer_id' => (int)$cid]);
        }
        if ($from) {
            $query->where(['DATE(Quotations.quotation_date) >=' => FrozenDate::parseDate($from, 'yyyy-MM-dd')]);
        }
        if ($to) {
            $query->where(['DATE(Quotations.quotation_date) <=' => FrozenDate::parseDate($to, 'yyyy-MM-dd')]);
        }

        // Keep filters in paginator links
        $this->paginate['url'] = ['?' => $this->request->getQueryParams()];
        $quotations = $this->paginate($query);

        // Options
        $statuses = [
            'DRAFT' => 'DRAFT',
            'SENT' => 'SENT',
            'APPROVED' => 'APPROVED',
            'CANCELLED' => 'CANCELLED',
            'EXPIRED' => 'EXPIRED',
        ];
        $customers = $this->Customers->find('list', [
            'keyField' => 'id', 'valueField' => 'name',
            'order' => ['name' => 'ASC'],
        ])->toArray();

        $this->set(compact('quotations', 'statuses', 'customers'));

		
    }
	 public function bulk()
    {
        $this->request->allowMethod(['post']);
        $action = (string)$this->request->getData('bulk_action');
        $ids = (array)$this->request->getData('ids'); // checkbox
        $ids = array_map('intval', array_filter($ids));

        if (!$action || !$ids) {
            $this->Flash->error(__('Please select rows and an action.'));
            return $this->redirect($this->referer(['action' => 'index'], true));
        }

        $affected = 0;
        switch ($action) {
            case 'approve':
                $affected = $this->Quotations->updateAll(['status' => 'APPROVED'], ['id IN' => $ids]);
                break;
            case 'cancel':
                $affected = $this->Quotations->updateAll(['status' => 'CANCELLED'], ['id IN' => $ids]);
                break;
            case 'delete':
                // hati-hati: delete satu-satu biar events/behaviors jalan
                $entities = $this->Quotations->find()->where(['id IN' => $ids])->all();
                foreach ($entities as $e) {
                    $this->Quotations->delete($e) && $affected++;
                }
                break;
            default:
                $this->Flash->error(__('Unknown action.'));
                return $this->redirect($this->referer(['action' => 'index'], true));
        }

        $this->Flash->success(__('{0} quotation(s) updated.', $affected));
        // Kembali ke index dengan query filter yang sama
        return $this->redirect(['action' => 'index', '?' => $this->request->getQueryParams()]);
    }

    
    public function view($id = null)
    {
        $salesQuotation = $this->SalesQuotations->get($id, contain: ['SalesQuotationLines']);
        $this->set(compact('salesQuotation'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $salesQuotation = $this->SalesQuotations->newEmptyEntity();
        if ($this->request->is('post')) {
            $salesQuotation = $this->SalesQuotations->patchEntity($salesQuotation, $this->request->getData());
            if ($this->SalesQuotations->save($salesQuotation)) {
                $this->Flash->success(__('The sales quotation has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sales quotation could not be saved. Please, try again.'));
        }
        $this->set(compact('salesQuotation'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Sales Quotation id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $salesQuotation = $this->SalesQuotations->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $salesQuotation = $this->SalesQuotations->patchEntity($salesQuotation, $this->request->getData());
            if ($this->SalesQuotations->save($salesQuotation)) {
                $this->Flash->success(__('The sales quotation has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sales quotation could not be saved. Please, try again.'));
        }
        $this->set(compact('salesQuotation'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Sales Quotation id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $salesQuotation = $this->SalesQuotations->get($id);
        if ($this->SalesQuotations->delete($salesQuotation)) {
            $this->Flash->success(__('The sales quotation has been deleted.'));
        } else {
            $this->Flash->error(__('The sales quotation could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
