
<div class="card">
  <div class="card-header"><h3 class="card-title">Quotation <?= h($quotation->code) ?></h3></div>
  <div class="card-body">
    <dl class="row">
      <dt class="col-sm-3">Customer</dt><dd class="col-sm-9"><?= h($quotation->partner->name ?? '') ?></dd>
      <dt class="col-sm-3">Date</dt><dd class="col-sm-9"><?= $quotation->quotation_date?->format('Y-m-d') ?></dd>
      <dt class="col-sm-3">Total</dt><dd class="col-sm-9"><?= $this->Number->format($quotation->total ?? 0) ?></dd>
      <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?= h($quotation->status) ?></dd>
    </dl>
  </div>
  <div class="card-footer">
    <?= $this->Html->link('Edit', ['action'=>'edit',$quotation->id], ['class'=>'btn btn-warning']) ?>
    <?= $this->Html->link('Back', ['action'=>'index'], ['class'=>'btn btn-secondary']) ?>
  </div>
</div>
