
<div class="card">
  <div class="card-header d-flex justify-content-between">
    <h3 class="card-title">Quotations</h3>
    <?= $this->Html->link('New Quotation', ['action' => 'add'], ['class' => 'btn btn-success btn-sm']) ?>
  </div>
  <div class="card-body">
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th><?= $this->Paginator->sort('code') ?></th>
          <th><?= $this->Paginator->sort('partner_id', 'Customer') ?></th>
          <th><?= $this->Paginator->sort('quotation_date') ?></th>
          <th class="text-end"><?= $this->Paginator->sort('total') ?></th>
          <th><?= $this->Paginator->sort('status') ?></th>
          <th class="text-center"><?= __('Actions') ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($quotations as $q): ?>
        <tr>
          <td><?= h($q->code) ?></td>
          <td><?= h($q->partner->name ?? '') ?></td>
          <td><?= $q->quotation_date?->format('Y-m-d') ?></td>
          <td class="text-end"><?= $this->Number->format($q->total ?? 0) ?></td>
          <td><span class="badge bg-secondary"><?= h($q->status) ?></span></td>
          <td class="text-center">
            <?= $this->Html->link('View', ['action' => 'view', $q->id], ['class'=>'btn btn-xs btn-primary']) ?>
            <?= $this->Html->link('Edit', ['action' => 'edit', $q->id], ['class'=>'btn btn-xs btn-warning']) ?>
            <?= $this->Form->postLink('Delete', ['action' => 'delete', $q->id], ['confirm'=>'Are you sure?', 'class'=>'btn btn-xs btn-danger']) ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class="mt-2">
      <?= $this->Paginator->numbers() ?>
    </div>
  </div>
</div>
