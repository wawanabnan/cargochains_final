<?php
/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\ResultSetInterface|\Sales\Model\Entity\Quotation[] $quotations
 * @var array $statuses
 * @var array $customers
 */
?>

<div class="card card-primary card-outline">
  <div class="card-header">
    <h3 class="card-title mb-0">Sales Quotations</h3>
  </div>

  <div class="card-body">
    <!-- FILTERS -->
    <div class="mb-3">
      <?= $this->Form->create(null, ['type' => 'get', 'class' => 'row g-2 align-items-end']) ?>
        <div class="col-md-3">
          <?= $this->Form->control('q', [
            'label' => 'Keyword',
            'value' => $this->request->getQuery('q'),
            'placeholder' => 'Code / Subject',
            'class' => 'form-control'
          ]) ?>
        </div>
        <div class="col-md-2">
          <?= $this->Form->control('status', [
            'label' => 'Status',
            'options' => ['' => '— All —'] + $statuses,
            'value' => $this->request->getQuery('status'),
            'class' => 'form-select'
          ]) ?>
        </div>
        <div class="col-md-3">
          <?= $this->Form->control('customer_id', [
            'label' => 'Customer',
            'options' => ['' => '— All —'] + $customers,
            'value' => $this->request->getQuery('customer_id'),
            'class' => 'form-select'
          ]) ?>
        </div>
        <div class="col-md-2">
          <?= $this->Form->control('from', [
            'label' => 'From',
            'type' => 'date',
            'value' => $this->request->getQuery('from'),
            'class' => 'form-control'
          ]) ?>
        </div>
        <div class="col-md-2">
          <?= $this->Form->control('to', [
            'label' => 'To',
            'type' => 'date',
            'value' => $this->request->getQuery('to'),
            'class' => 'form-control'
          ]) ?>
        </div>
        <div class="col-12 d-flex gap-2">
          <?= $this->Form->button(__('Filter'), ['class' => 'btn btn-primary']) ?>
          <a href="<?= $this->Url->build(['_name' => 'sales:quotations:index']) ?>" class="btn btn-outline-secondary"><?= __('Reset') ?></a>
          <a href="<?= $this->Url->build(['action' => 'add']) ?>" class="btn btn-success ms-auto"><?= __('New Quotation') ?></a>
        </div>
      <?= $this->Form->end() ?>
    </div>

    <!-- BULK ACTION + TABLE -->
    <?= $this->Form->create(null, ['url' => ['_name' => 'sales:quotations:bulk'], 'class' => 'mb-2']) ?>
      <div class="d-flex align-items-center gap-2 mb-2">
        <?= $this->Form->select('bulk_action', [
          '' => '— Bulk Action —',
          'approve' => 'Approve',
          'cancel'  => 'Cancel',
          'delete'  => 'Delete',
        ], ['class' => 'form-select w-auto']) ?>
        <?= $this->Form->button(__('Apply'), ['class' => 'btn btn-outline-primary']) ?>
      </div>

      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead>
            <tr>
              <th style="width:34px;">
                <input type="checkbox" id="chk-all" class="form-check-input" />
              </th>
              <th><?= $this->Paginator->sort('code', 'Code') ?></th>
              <th>Customer</th>
              <th><?= $this->Paginator->sort('quotation_date', 'Date') ?></th>
              <th class="text-end"><?= $this->Paginator->sort('total', 'Total') ?></th>
              <th><?= $this->Paginator->sort('status', 'Status') ?></th>
              <th class="text-center" style="width:150px;"><?= __('Actions') ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($quotations as $q): ?>
              <tr>
                <td>
                  <input type="checkbox" name="ids[]" value="<?= (int)$q->id ?>" class="row-check form-check-input" />
                </td>
                <td><?= h($q->code) ?></td>
                <td><?= h($q->customer->name ?? '') ?></td>
                <td><?= $q->quotation_date ? $q->quotation_date->format('Y-m-d') : '' ?></td>
                <td class="text-end"><?= $this->Number->format($q->total ?? 0) ?></td>
                <td>
                  <?php
                    $badge = match ($q->status) {
                      'APPROVED'  => 'badge bg-success',
                      'CANCELLED' => 'badge bg-secondary',
                      'SENT'      => 'badge bg-info',
                      'EXPIRED'   => 'badge bg-danger',
                      default     => 'badge bg-warning text-dark', // DRAFT
                    };
                  ?>
                  <span class="<?= $badge ?>"><?= h($q->status) ?></span>
                </td>
                <td class="text-center">
                  <?= $this->Html->link(__('View'), ['action' => 'view', $q->id], ['class' => 'btn btn-xs btn-primary']) ?>
                  <?= $this->Html->link(__('Edit'), ['action' => 'edit', $q->id], ['class' => 'btn btn-xs btn-warning']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?= $this->Form->end() ?>

    <!-- PAGINATION -->
    <div class="d-flex justify-content-between align-items-center mt-2">
      <div>
        <ul class="pagination pagination-sm m-0">
          <?= $this->Paginator->first('<< ' . __('First')) ?>
          <?= $this->Paginator->prev('< ' . __('Prev')) ?>
          <?= $this->Paginator->numbers() ?>
          <?= $this->Paginator->next(__('Next') . ' >') ?>
          <?= $this->Paginator->last(__('Last') . ' >>') ?>
        </ul>
      </div>
      <small class="text-muted">
        <?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}}/{{count}}')) ?>
      </small>
    </div>
  </div>
</div>

<?php // Select all JS (ringan) ?>
<?php $this->Html->scriptStart(['block' => true]); ?>
document.getElementById('chk-all')?.addEventListener('change', function(e) {
  document.querySelectorAll('.row-check').forEach(cb => cb.checked = e.target.checked);
});
<?php $this->Html->scriptEnd(); ?>
