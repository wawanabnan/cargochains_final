<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class CreateServices extends AbstractMigration
{
    public function change(): void
    {
        // services: tree (parent_id, lft, rght), name, transport_mode
        $table = $this->table('services');
        $table
            ->addColumn('parent_id', 'integer', ['null' => true, 'default' => null])
            ->addColumn('lft', 'integer', ['null' => true, 'default' => null])
            ->addColumn('rght', 'integer', ['null' => true, 'default' => null])
            ->addColumn('name', 'string', ['limit' => 100, 'null' => false])
            ->addColumn('transport_mode', 'string', ['limit' => 20, 'null' => true, 'default' => null]) // SEA|AIR|INLAND
            ->addColumn('created', 'datetime', ['null' => true, 'default' => null])
            ->addColumn('modified', 'datetime', ['null' => true, 'default' => null])
            ->addIndex(['parent_id'])
            ->addIndex(['lft'])
            ->addIndex(['rght'])
            ->create();
    }
}
