<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class AddServiceIdToSalesQuotations extends AbstractMigration
{
    public function change(): void
    {
        $this->table('sales_quotations')
            ->addColumn('service_id', 'integer', ['null' => true, 'default' => null])
            ->addIndex(['service_id'])
            ->addForeignKey(
                'service_id',
                'services',
                'id',
                ['delete' => 'SET_NULL', 'update' => 'NO_ACTION']
            )
            ->update();
    }
}
