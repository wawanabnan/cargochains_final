<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class AddValidUntilToSalesQuotations extends AbstractMigration
{
    public function change(): void
    {
        $this->table('sales_quotations')
            ->addColumn('valid_until', 'date', [
                'null' => true,      // aman untuk data lama; ubah ke false kalau mau wajib
                'default' => null,
            ])
            ->update();
    }
}
