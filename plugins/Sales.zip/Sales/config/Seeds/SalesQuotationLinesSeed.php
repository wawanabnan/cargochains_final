<?php
declare(strict_types=1);

use Migrations\AbstractSeed;

class SalesQuotationLinesSeed extends AbstractSeed
{
    public function run(): void
    {
        // Ambil semua quotation yang baru dibuat
        $quotes = $this->fetchAll('SELECT id FROM sales_quotations');

        // SESUAIKAN pool lokasi dengan data geo_locations Anda
        $geoPool = [1, 2, 3, 4, 5]; // FK ke geo_locations.id yang ada

        $rows = [];
        $now = date('Y-m-d H:i:s');

        foreach ($quotes as $q) {
            $qid = (int)$q['id'];
            $lineCount = rand(1, 4);

            for ($n = 1; $n <= $lineCount; $n++) {
                $origin = $geoPool[array_rand($geoPool)];
                do {
                    $dest = $geoPool[array_rand($geoPool)];
                } while ($dest === $origin);

                $qty   = rand(1, 10);
                $price = rand(50, 500) * 1000; // contoh harga
                $amount = $qty * $price;

                $rows[] = [
                    'sales_quotation_id' => $qid,
                    'origin_id'    => $origin,
                    'destination_id'=> $dest,
                    'description'  => "Freight service #$n for Q$qid",
                    'qty'          => $qty,
                    'price'        => $price,
                    'amount'       => $amount,
                    'created'      => $now,
                    'modified'     => $now,
                ];
            }
        }

        if ($rows) {
            $this->table('sales_quotation_lines')->insert($rows)->save();
        }
    }
}
