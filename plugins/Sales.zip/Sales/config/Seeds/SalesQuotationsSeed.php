<?php
declare(strict_types=1);

use Migrations\AbstractSeed;

class SalesQuotationsSeed extends AbstractSeed
{
    public function run(): void
    {
        $now = date('Y-m-d H:i:s');
        $statuses = ['DRAFT', 'SENT', 'CONFIRMED', 'CANCELED'];

        // SESUAIKAN pool ID ini dengan data nyata Anda:
        $customerPool = [1, 2, 3, 4, 5]; // FK ke partners.id yang memang ada

        $rows = [];
        for ($i = 1; $i <= 20; $i++) {
            $rows[] = [
                // biarkan 'id' auto-increment kalau schema Anda begitu
                'number' => sprintf('Q%05d', $i),
                'customer_id'  => $customerPool[array_rand($customerPool)],
                'valid_until'  => date('Y-m-d', strtotime('+' . rand(7, 30) . ' days')),
                'status'       => $statuses[array_rand($statuses)],
                'created'      => $now,
                'modified'     => $now,
            ];
        }

        $this->table('sales_quotations')->insert($rows)->save();
    }
}
