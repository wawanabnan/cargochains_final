<?php
declare(strict_types=1);

use Migrations\AbstractSeed;

class SalesDemoSeed extends AbstractSeed
{
    public function run(): void
    {
        // urutan penting: header dulu → lines
        $this->call('SalesQuotationsSeed');
        $this->call('SalesQuotationLinesSeed');
    }
}
