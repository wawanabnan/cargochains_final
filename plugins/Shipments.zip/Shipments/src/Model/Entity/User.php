<?php
declare(strict_types=1);

namespace Accounts\Model\Entity;

use Cake\ORM\Entity;

class User extends Entity
{
    protected array $_accessible = ['*' => true, 'id' => false];
}
