<?php
declare(strict_types=1);

namespace Shipments\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
}
