<?php
declare(strict_types=1);

namespace Shipments\Controller;

class ShipmentsController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();
      //  $this->loadModel('Shipments.Shipments');
        // Kalau perlu list dropdown Partner:
       // $this->Partners = $this->fetchTable('Partners.Partners');
    }

    public function index()
    {
        $this->paginate = [
            'contain' => ['Shipper', 'Consignee', 'Carrier', 'Agency'],
            'order' => ['Shipments.created' => 'DESC'],
        ];
        $shipments = $this->paginate($this->Shipments);
        $this->set(compact('shipments'));
    }

    public function view($id = null)
    {
        $shipment = $this->Shipments->get($id, [
            'contain' => ['Shipper', 'Consignee', 'Carrier', 'Agency', 'ShipmentRoutes', 'ShipmentDocuments'],
        ]);
        $this->set(compact('shipment'));
    }

    public function add()
    {
        $shipment = $this->Shipments->newEmptyEntity();
        if ($this->request->is('post')) {
            $shipment = $this->Shipments->patchEntity($shipment, $this->request->getData());
            if ($this->Shipments->save($shipment)) {
                $this->Flash->success('Shipment berhasil dibuat.');
                return $this->redirect(['action' => 'view', $shipment->id]);
            }
            $this->Flash->error('Gagal menyimpan shipment.');
        }

        // Dropdown partner (opsional: filter per peran)
        $shippers   = $this->Partners->find('list')->where(['is_shipper' => true])->orderAsc('name')->all();
        $consignees = $this->Partners->find('list')->where(['is_consignee' => true])->orderAsc('name')->all();
        $carriers   = $this->Partners->find('list')->where(['is_carrier' => true])->orderAsc('name')->all();
        $agencies   = $this->Partners->find('list')->where(['is_agent' => true])->orderAsc('name')->all();

        $this->set(compact('shipment', 'shippers', 'consignees', 'carriers', 'agencies'));
    }

    public function edit($id = null)
    {
        $shipment = $this->Shipments->get($id);
        if ($this->request->is(['patch','post','put'])) {
            $shipment = $this->Shipments->patchEntity($shipment, $this->request->getData());
            if ($this->Shipments->save($shipment)) {
                $this->Flash->success('Shipment berhasil diperbarui.');
                return $this->redirect(['action' => 'view', $shipment->id]);
            }
            $this->Flash->error('Gagal memperbarui shipment.');
        }

        $shippers   = $this->Partners->find('list')->where(['is_shipper' => true])->orderAsc('name')->all();
        $consignees = $this->Partners->find('list')->where(['is_consignee' => true])->orderAsc('name')->all();
        $carriers   = $this->Partners->find('list')->where(['is_carrier' => true])->orderAsc('name')->all();
        $agencies   = $this->Partners->find('list')->where(['is_agent' => true])->orderAsc('name')->all();

        $this->set(compact('shipment', 'shippers', 'consignees', 'carriers', 'agencies'));
    }
}
