<?php
declare(strict_types=1);

namespace Accounts\Controller;

class UsersController extends AppController
{
    public function initialize(): void
    {
        parent::initialize();
        $this->loadModel('Accounts.Users');
        $this->Authentication->allowUnauthenticated(['login']);
    }

    public function login()
    {
        $this->request->allowMethod(['get','post']);
        $result = $this->Authentication->getResult();
        if ($result && $result->isValid()) {
            // redirect ke halaman aman (ubah sesuai kebutuhan)
            $target = $this->request->getQuery('redirect', '/');
            return $this->redirect($target);
        }
        if ($this->request->is('post') && (!$result || !$result->isValid())) {
            $this->Flash->error('Invalid username or password');
        }
    }

    public function logout()
    {
        $this->request->allowMethod(['post','get']);
        $this->Authentication->logout();
        return $this->redirect(['plugin' => 'Accounts', 'controller' => 'Users', 'action' => 'login']);
    }
}
