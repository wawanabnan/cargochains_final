<?php
declare(strict_types=1);

namespace Shipments\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

class ShipmentsFixture extends TestFixture
{
    public string $table = 'shipments';

    public array $records = [[
        'id' => 1,
        'number' => 'SHP-2025-0001',
        'origin_id' => 10,
        'destination_id' => 20,
        'cargo_description' => 'Electronics parts',
        'weight' => 1200.500,
        'volume' => 3.250,
        'qty' => 100,
        'shipper_id' => 101,
        'consignee_id' => 202,
        'carrier_id' => 303,
        'agency_id' => 404,
        'etd' => '2025-09-15',
        'eta' => '2025-09-27',
        'atd' => null,
        'ata' => null,
        'status' => 'DRAFT',
        'is_multimoda' => 1,
        'origin' => 'Jakarta',
        'destination' => 'Singapore',
        'bill_of_lading_no' => null,
        'total' => null,
        'created' => '2025-09-11 00:00:00',
        'modified' => '2025-09-11 00:00:00',
    ]];
}
